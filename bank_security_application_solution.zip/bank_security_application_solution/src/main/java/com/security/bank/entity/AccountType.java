package com.security.bank.entity;

public enum AccountType {
    SAVINGS,
    CURRENT,
    PPF,
    SALARY
}

