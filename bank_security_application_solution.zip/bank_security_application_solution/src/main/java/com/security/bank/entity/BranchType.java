package com.security.bank.entity;

public enum BranchType {
    SBI,ICIC,BOB,HDFC
}
